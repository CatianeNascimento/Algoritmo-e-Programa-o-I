/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

import java.util.Scanner;

/**
 *
 * @author csnas
 */
public class Exercicio06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String nome, sexo, aluno = "Caty", genero; 
        int i=1,idade, maior=0; 
        
        
        do {
            System.out.println("Insira o nome do aluno: ");
            nome = input.next();
            System.out.println("Insira o genero do aluno: ");
            sexo = input.next();
            System.out.println("Insira a idade do aluno: ");
            idade = input.nextInt(); 
            if(idade > maior) {
            maior = idade;
            aluno = nome;
            genero = sexo;
            }
            i++;
            } 
        while (i <= 5);
        
        System.out.println("O aluno mais velho é " + aluno);
        
        
      


}
}




    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

/**
 *
 * @author csnas
 */
public class Exercicio08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int soma=0, i, media;
        
      for(i=13; i<=73; i++) {
          if(i % 2 == 0) {
            soma= soma + i; 
          
  }
      }
       media = soma/30;
            System.out.println(soma);
              System.out.println("a media aritmetica dos números pares entre 13 e 73, é " + media);
          
      } 
    }
    


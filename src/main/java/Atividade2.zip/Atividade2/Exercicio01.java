/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

/** Exercício 1 - Sequencia de números inteiros do 1 ao 50. 
 *
 * @author Catiane 
 */
public class Exercicio01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int n = 1; 
       
       while(n <=50) {
           System.out.println(n);
           n++;
       }
    }
    
}

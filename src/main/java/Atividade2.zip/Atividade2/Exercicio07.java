/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

/**
 *
 * @author csnas
 */
public class Exercicio07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = 6; 
        
      
        while(n <=200) {
            n++;
             if(n % 7 == 0){
            System.out.println(n);
         
        }
    }
    
    }
}

    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

import java.util.Scanner;

/**
 *
 * @author csnas
 */
public class Exercicio09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); 
        
        int numAlunos, nota, rep=0, soma=0, media; 
        
        System.out.println("Insira os números de alunos: ");
        numAlunos = input.nextInt(); 
        
        while(rep < numAlunos) {
            System.out.println("Insira a nota de cada aluno ");
            nota = input.nextInt();
            rep++;
         soma = soma + nota; 
      
    }
        media = soma / rep;
        System.out.println("A média aritmética das notas é de: " + media);
   
}

}
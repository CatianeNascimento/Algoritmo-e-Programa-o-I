/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

import java.util.Scanner;

/**
 *
 * @author csnas
 */
public class Exercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int n;
        int maior=0; 
        
        for(int i=1; i<=10; i++) { 
        System.out.println("Insira um número ");
        n = input.nextInt();
        
        if(n > maior)
                maior = n;     
    }
        
        System.out.println("O maior número é " + maior);
}

}
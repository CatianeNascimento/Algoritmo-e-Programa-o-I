/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

import java.util.Scanner;

/** Exercicio 2 - 
 *
 * @author csnas
 */
public class Exercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int n, numero=1, soma=0; 
        
        System.out.println("Insira um número: ");
        n = input.nextInt();
       
        while(numero <=n) {
          soma = soma + numero; 
          numero = numero+1;
        }
       
        System.out.println("A soma é de " + soma);
    }
    
}

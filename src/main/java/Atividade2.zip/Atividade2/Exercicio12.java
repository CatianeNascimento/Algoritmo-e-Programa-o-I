/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Atividade2;

import java.util.Scanner;

/**
 *
 * @author csnas
 */
public class Exercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        float soma=0, denominador, numerador=1, div, soma1, soma2;
        
        System.out.println("Insira o valor do denominador: ");
        denominador = input.nextFloat();
       
       while(denominador > 0) {
           div = numerador / denominador;
           soma = soma + div; 
           denominador--;
       }
       soma1 = soma + (denominador - 1) / 2;
       soma2 = soma1 + denominador /1;
  
        System.out.println("A soma de todos os resultados da divisão é "+ soma2);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ADO3;

import java.util.Scanner;

/**
 *
 * @author Catiane
 */
public class Exercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int n, mult; 
        
        System.out.println("Insira um número maior que 2 e menor que 1000: ");
        n = input.nextInt();
        
        for(int i=1; i<=10; i++) {
            mult = i*n;
            System.out.println(i + " x " +  n +  " = " + mult);
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ADO3;

/** Exercício 1 -Faça um programa que mostre os números pares entre 1 e 100, 
inclusive. 
 *
 * @author Catiane
 */
public class Exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        for(int i=1; i<=100; i++) {
            if(i % 2 ==0) {
                System.out.println(i + "\n Número par");
            }
        }
    }
    
}
